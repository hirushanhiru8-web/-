/**
 * MKV School T-Shirt Order backend
 * 1) Create a Google Sheet and paste its ID below.
 * 2) Set a private ADMIN_KEY.
 * 3) Deploy as Web app: Execute as Me / Anyone.
 */
const SHEET_ID = 'PASTE_GOOGLE_SHEET_ID_HERE';
const ADMIN_KEY = 'CHANGE_THIS_TO_A_LONG_RANDOM_ADMIN_KEY';
const EMAIL_TO = 'hirushanhiru8@gmail.com';
const SHEET_NAME = 'Orders';

function setup(){
  const ss=SpreadsheetApp.openById(SHEET_ID);
  let sh=ss.getSheetByName(SHEET_NAME)||ss.insertSheet(SHEET_NAME);
  if(sh.getLastRow()===0) sh.appendRow(['Order Number','Student Name','Class','Size','Quantity','Price','Total','Guardian','Contact','Preference','Notes','Order Date','Status']);
}
function json(o){return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);}
function doPost(e){
  try{
    const d=JSON.parse(e.postData.contents||'{}');
    if(d.action==='updateStatus') return updateStatus(d);
    if(!d.studentName||!d.className||!d.size||!d.quantity||!d.guardianName||!d.contact) throw new Error('Missing required fields.');
    const orderNumber=d.orderNumber||('MKV-'+new Date().getFullYear()+'-'+Utilities.getUuid().slice(0,6).toUpperCase());
    const sh=SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);
    const now=new Date();
    sh.appendRow([orderNumber,d.studentName,d.className,d.size,Number(d.quantity),2500,Number(d.total),d.guardianName,d.contact,d.preference||'',d.notes||'',now,'Pending']);
    MailApp.sendEmail({to:EMAIL_TO,subject:`New MKV T-Shirt Order — ${orderNumber}`,htmlBody:emailHtml(d,orderNumber,now)});
    return json({ok:true,orderNumber});
  }catch(err){return json({ok:false,error:String(err.message||err)});}
}
function doGet(e){
  try{
    if(e.parameter.action!=='list') return json({ok:true,service:'MKV T-Shirt Orders'});
    if(e.parameter.key!==ADMIN_KEY) throw new Error('Invalid admin key.');
    const sh=SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);const values=sh.getDataRange().getValues();
    if(values.length<2)return json({ok:true,orders:[]});
    const h=values.shift();const orders=values.map(r=>Object.fromEntries(h.map((k,i)=>[mapKey(k),r[i]]))).map(o=>{if(o.orderDate instanceof Date)o.orderDate=o.orderDate.toISOString();return o;});
    orders.reverse(); return json({ok:true,orders});
  }catch(err){return json({ok:false,error:String(err.message||err)});}
}
function mapKey(k){return {'Order Number':'orderNumber','Student Name':'studentName','Class':'className','Size':'size','Quantity':'quantity','Price':'price','Total':'total','Guardian':'guardianName','Contact':'contact','Preference':'preference','Notes':'notes','Order Date':'orderDate','Status':'status'}[k]||k;}
function updateStatus(d){
  if(d.key!==ADMIN_KEY) throw new Error('Invalid admin key.');
  const sh=SpreadsheetApp.openById(SHEET_ID).getSheetByName(SHEET_NAME);const data=sh.getDataRange().getValues();
  for(let i=1;i<data.length;i++){if(String(data[i][0])===String(d.orderNumber)){sh.getRange(i+1,13).setValue(d.status);return json({ok:true});}}
  throw new Error('Order not found.');
}
function emailHtml(d,orderNumber,now){
  const esc=s=>String(s??'').replace(/[&<>]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;'}[m]));
  return `<div style="font-family:Arial,sans-serif;max-width:650px;margin:auto;border:1px solid #eee;border-radius:18px;overflow:hidden"><div style="background:#730912;color:#fff;padding:22px"><b style="font-size:20px">MKV T-Shirt Order</b><div style="opacity:.75;margin-top:5px">KG/DEHI/MUDUGAMUWA.K.V • Ruwanwalla</div></div><div style="padding:24px"><h2>New order received</h2><p><b>Order:</b> ${esc(orderNumber)}</p><table style="width:100%;border-collapse:collapse"><tr><td style="padding:8px;border-bottom:1px solid #eee">Student</td><td style="padding:8px;border-bottom:1px solid #eee"><b>${esc(d.studentName)}</b></td></tr><tr><td style="padding:8px;border-bottom:1px solid #eee">Class</td><td style="padding:8px;border-bottom:1px solid #eee">${esc(d.className)}</td></tr><tr><td style="padding:8px;border-bottom:1px solid #eee">Size</td><td style="padding:8px;border-bottom:1px solid #eee">${esc(d.size)}</td></tr><tr><td style="padding:8px;border-bottom:1px solid #eee">Quantity</td><td style="padding:8px;border-bottom:1px solid #eee">${esc(d.quantity)}</td></tr><tr><td style="padding:8px;border-bottom:1px solid #eee">Total</td><td style="padding:8px;border-bottom:1px solid #eee"><b>Rs. ${Number(d.total).toLocaleString('en-LK')}.00</b></td></tr><tr><td style="padding:8px;border-bottom:1px solid #eee">Guardian</td><td style="padding:8px;border-bottom:1px solid #eee">${esc(d.guardianName)}</td></tr><tr><td style="padding:8px;border-bottom:1px solid #eee">Contact</td><td style="padding:8px;border-bottom:1px solid #eee">${esc(d.contact)}</td></tr><tr><td style="padding:8px">Pickup</td><td style="padding:8px">${esc(d.preference)}</td></tr></table><p style="color:#777;font-size:12px">Notes: ${esc(d.notes||'None')}</p><p style="color:#777;font-size:12px">Received: ${now.toLocaleString()}</p></div></div>`;
}
