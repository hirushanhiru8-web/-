# KG/DEHI/MUDUGAMUWA.K.V — School T-Shirt Ordering Website

A mobile-first, animated school T-shirt ordering site using the supplied front/back T-shirt images.

## What is included
- Responsive student/parent ordering page
- Front/back product gallery
- Live order summary and total calculation
- Animated hero/product sections
- Order success screen with order number
- Google Apps Script backend
- Email notification to `hirushanhiru8@gmail.com`
- Google Sheet order storage
- Admin dashboard with search/filter/status updates/CSV export

## Important: email + admin backend setup
A static GitHub Pages site cannot securely send email or maintain a shared order database by itself. This package includes a free Google Apps Script backend for that.

### 1. Create the Google Sheet
Create a Google Sheet and copy its ID from the URL.

### 2. Configure Apps Script
Open `google-apps-script/Code.gs` in script.google.com, paste the code into a new project and set:
- `SHEET_ID = '...'`
- `ADMIN_KEY = '...'` (use a long random value)
- `EMAIL_TO` is already `hirushanhiru8@gmail.com`

Run `setup()` once and authorize the script.

### 3. Deploy
Deploy → New deployment → Web app.
- Execute as: Me
- Who has access: Anyone
Copy the Web App URL.

### 4. Put the Web App URL into the website
In `app.js` replace `PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE` with the Web App URL.
Do the same in `admin.js`.

### 5. GitHub Pages
Upload the whole project (including the `assets` folder) to your GitHub repository and enable GitHub Pages.

Open `admin.html` for the order dashboard and enter the same `ADMIN_KEY` you configured in Apps Script.

## Security note
The admin key is used as a basic application-level gate. For a school ordering site with sensitive personal information, keep the dashboard URL private and consider adding a proper authenticated backend if the site is used at large scale.
