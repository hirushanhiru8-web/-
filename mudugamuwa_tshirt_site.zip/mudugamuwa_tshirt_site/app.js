const PRICE = 2500;
// Paste your deployed Google Apps Script Web App URL here.
const API_URL = 'PASTE_YOUR_GOOGLE_APPS_SCRIPT_WEB_APP_URL_HERE';

const form = document.getElementById('orderForm');
const qty = form.elements.quantity;
const nameInput = form.elements.studentName;
const sizeInput = form.elements.size;
const sumStudent = document.getElementById('sumStudent');
const sumSize = document.getElementById('sumSize');
const sumQty = document.getElementById('sumQty');
const sumTotal = document.getElementById('sumTotal');
const toast = document.getElementById('toast');
const submitBtn = document.getElementById('submitBtn');

function money(n){ return `Rs. ${Number(n).toLocaleString('en-LK')}.00`; }
function updateSummary(){
  const q = Math.max(1, Number(qty.value || 1));
  qty.value = q;
  sumStudent.textContent = nameInput.value.trim() || '—';
  sumSize.textContent = sizeInput.value || '—';
  sumQty.textContent = q;
  sumTotal.textContent = money(q * PRICE);
}
[nameInput, sizeInput, qty].forEach(el => el.addEventListener('input', updateSummary));
form.addEventListener('change', updateSummary); updateSummary();

function showToast(msg){ toast.textContent = msg; toast.classList.add('show'); setTimeout(()=>toast.classList.remove('show'),3500); }
function makeLocalOrderNumber(){ return 'MKV-' + new Date().getFullYear() + '-' + Math.random().toString(36).slice(2,8).toUpperCase(); }

form.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const data = Object.fromEntries(new FormData(form).entries());
  data.quantity = Number(data.quantity);
  data.price = PRICE;
  data.total = data.quantity * PRICE;
  data.orderNumber = makeLocalOrderNumber();
  data.orderDate = new Date().toISOString();
  data.status = 'Pending';

  submitBtn.disabled = true; submitBtn.innerHTML = 'Sending order…';
  try{
    if(API_URL.includes('PASTE_YOUR_')) throw new Error('API not configured');
    const res = await fetch(API_URL, { method:'POST', headers:{'Content-Type':'text/plain;charset=utf-8'}, body:JSON.stringify(data) });
    const result = await res.json();
    if(!result.ok) throw new Error(result.error || 'Submission failed');
    document.getElementById('orderNumber').textContent = result.orderNumber || data.orderNumber;
    document.getElementById('order').classList.add('hidden');
    document.getElementById('success').classList.remove('hidden');
    document.getElementById('success').scrollIntoView({behavior:'smooth'});
  }catch(err){
    console.error(err);
    if(err.message === 'API not configured') showToast('Please configure the school order backend first.');
    else showToast('Order could not be submitted. Please try again or call 0778737135.');
  }finally{ submitBtn.disabled=false; submitBtn.innerHTML='Submit Order <span>→</span>'; }
});
